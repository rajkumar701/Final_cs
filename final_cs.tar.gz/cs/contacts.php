<?php

$to = 'graj.kumar701@gmail.com';
$subject = 'this is subject';

$name = $_POST['icon_prefix'];
$telephone = $_POST['icon_telephone'];
$email = $_POST['email'];
$message = $_POST['icon_prefix2'];

$message=<<<EMAIL
name : $name
telephone : $telephone
email : $email
message : $message
EMAIL;

$header = '$email' ;

if($_POST){
mail($to, $subject, $message, $header);
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
  	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  	<link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  	<link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
  	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
  		<title>IITJ-Counselling Service</title>
      <link rel="shortcut icon" href="logo.jpg">
  	<link href='http://fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
	  	<script src="https://maps.googleapis.com/maps/api/js"></script>
    		<script>
			var map,marker;
			var iitj=new google.maps.LatLng(26.2712168,73.0329358);
			var gpra=new google.maps.LatLng(26.2003991,73.0408967);
      		function initialize() {
        	var mapCanvas = document.getElementById('map');
        	var mapOptions = {
          	center: iitj,
          	zoom: 17,
          	mapTypeId: google.maps.MapTypeId.ROADMAP,
		  	scrollwheel: false
        	};
        	map = new google.maps.Map(mapCanvas, mapOptions);
		
			marker=new google.maps.Marker({
			position:iitj,
			animation:google.maps.Animation.BOUNCE
			});
			marker.setMap(map);
      		}
	  
     	 	google.maps.event.addDomListener(window, 'load', initialize);
	  		google.maps.event.addDomListener(window, 'resize', initialize);
	  
	 	 	function map_gpra() {
			marker.setPosition(gpra);
			map.setCenter(gpra);
			//map.setZoom(16.3);
	  		}
	  		function map_iitj() {
			marker.setPosition(iitj);
			map.setCenter(iitj);
			//map.setZoom(17);
	  		}
    		</script>
</head>
<body bgcolor="#ECF0F1">
    &nbsp;
    <div class="container" >
    <nav>
      <div class="nav-wrapper">
      <a href="#!" class="brand-logo"><h5>&nbsp;&nbsp;IITJ Counselling Service</h5></a>
      <a href="#" data-activates="mobile-demo" class="button-collapse"><i class="material-icons">menu</i></a>
      <!-- Desktop Menu -->
      <ul class="right hide-on-med-and-down">
        <li class=""><a href="home.html">HOME</a></li>
        <li><a href="team.html">TEAM</a></li>
        <li><a class="dropdown-button" href="#!" data-activates="dropdown1">Life At IITJ<i class="material-icons right">arrow_drop_down</i></a></li>
          <ul id="dropdown1" class="dropdown-content">
            <li ><a href="societies.html">Societies</a></li>
            <li class="divider"></li>
            <li><a href="committees.html">Committees</a></li>
            <li class="divider"></li>
            <li><a href="festivals.html">Festivals</a></li>
            <li class="divider"></li>
            <li><a href="http://www.iitjecell.in/">E-Cell</a></li>
            <li class="divider"></li>
            <li><a href="parivartan.html">Parivartan</a></li>
            
        </ul>
        <li><a class="dropdown-button" href="#!" data-activates="dropdown2">FAQs<i class="material-icons right">arrow_drop_down</i></a></li>
          <ul id="dropdown2" class="dropdown-content">
            <li><a href="general_faq.html">GENERAL FAQs</a></li>
            <li class="divider"></li>
            <li><a href="academics_faq.html">ACADEMICS</a></li>
            <li class="divider"></li>
            <li><a href="counselling_faq.html">COUNCELLING SERVICE</a></li>
            <li class="divider"></li>
            <li><a href="residential_faq.html">RESIDENTIAL CAMPUS</a></li>
          </ul>
        <li><a href="gallery.html">GALLERY</a></li>
        <li class="active"><a href="contacts.php">CONTACT US</a></li>
      </ul>
      <!-- Mobile Menu -->
      <ul class="side-nav" id="mobile-demo">
        <li class=""><a href="home.html">HOME</a></li>
        <li><a href="team.html">TEAM</a></li>
        <ul class="collapsible grey-text text-darken-3" data-collapsible="accordion">
          <li>
            <div class="collapsible-header">Life At IITJ</div>
            <ul class="collapsible-body">
              <li ><a href="societies.html">Societies</a></li>
              <li class="divider"></li>
              <li><a href="committees.html">Committees</a></li>
              <li class="divider"></li>
              <li><a href="festivals.html">Festivals</a></li>
              <li class="divider"></li>
              <li><a href="http://www.iitjecell.in/">E-Cell</a></li>
              <li class="divider"></li>
              <li><a href="parivartan.html">Parivartan</a></li>
              
            </ul>
          </li>
          <li>
            <div class="collapsible-header">FAQs</div>
            <ul class="collapsible-body">
              <li><a href="general_faq.html">GENERAL FAQs</a></li>
              <li class="divider"></li>
              <li><a href="academics_faq.html">ACADEMICS</a></li>
              <li class="divider"></li>
              <li><a href="counselling_faq.html">COUNCELLING SERVICE</a></li>
              <li class="divider"></li>
              <li><a href="residential_faq.html">RESIDENTIAL CAMPUS</a></li>
            </ul>
          </li>
        </ul>
        <li ><a href="gallery.html">GALLERY</a></li>
        <li class="active"><a href="contacts.php">CONTACT US</a></li>
      </ul>
      </div>
    </nav>
    </div>
  	&nbsp;
  	<div class="container" >
  		  <div class="card-panel">
  			    <div class="row">
                <form class="col s12" action="?" method="post">
                    <p><font size="6" color="red">Contact Us:</font></p>
                    <p><font size="4" color="black">Please fill in this form if you have any query regarding IIT Jodhpur. IIT Jodhpur Counselling Service team will be happy to help you anytime:</font></p>

                    <div class="row">
                      
                        <div class="input-field col s12">
                            <i class="material-icons prefix">account_circle</i>
                            <input id="icon_prefix" type="text" class="validate">
                            <label for="icon_prefix">Name</label>
                        </div>
                        <div class="input-field col s12">
                            <i class="material-icons prefix">phone</i>
                            <input id="icon_telephone" type="tel" class="validate">
                            <label for="icon_telephone">Telephone</label>
                        </div>
                        <div class="input-field col s12">
                            <i class="material-icons prefix">email</i>
                            <input id="email" type="email" class="validate">
                            <label for="email" data-error="wrong" data-success="right">Email</label>
                        </div>
                        <div class="input-field col s12">
                            <i class="material-icons prefix">mode_edit</i>
                            <textarea id="icon_prefix2" class="materialize-textarea"></textarea>
                            <label for="icon_prefix2">Message</label>
                        </div>
                      
                    </div>
                    <button class="btn waves-effect waves-light" type="submit" name="action">Submit
                        <i class="material-icons right">send</i>
                    </button>
                </form>
            </div>
  		  </div>
  	</div>
  	<div class="container">
      <footer class="page-footer">
            <div class="row">
                <div class="col l4 s12">
                  <h5 class="white-text">&nbsp;QUICK LINKS</h5><br>
                  
                      <a class="white-text" href="http://iitj.ac.in/">&nbsp;IIT JODHPUR</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <a class="white-text" href="http://iitj-varchas.org/">&nbsp;Varchas</a><br>
                      <a class="white-text" href="http://students.iitj.ac.in/">&nbsp;Student Gymkhana</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      <a class="white-text" href="http://ignus.org/">&nbsp;Ignus</a><br>
                      <a class="white-text " href="http://www.iitjecell.in/">&nbsp;E-cell</a><br>
                      
                  
                </div>
                <div class="col l6 offset-l2 s12">
          <button class="btn" onclick="map_gpra()">Map GPRA</button><button class="btn" onclick="map_iitj()">Map IITJ</button>
              <div style="width:100%;height:200px;" id="map">
                  <!--Map comes here-->
              </div>
            </div>
            </div>         
            <div class="footer-copyright">
              <div class="container">
                © Copyright 2016. All Rights Reserved. 
                <a class="grey-text text-lighten-4 right" >Maintained by: IIT Jodhpur </a>
              </div>
            </div>
        </footer>
    </div>
<script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
<script type="text/javascript" src="js/materialize.min.js"></script>
<script type="text/javascript" src="js/init.js"></script>
</body>
</html>