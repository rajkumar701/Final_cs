<?php
$name = $_POST['icon_prefix'];
$telephone = $_POST['icon_telephone'];
$email = $_POST['email'];
$message = $_POST['icon_prefix2'];
$to = "kumar.9@iitj.ac.in";
$subject = "Request";
$body = "this is body  \n\n\n$name\n$telephone\n$email\n$message";
mail ($to,$subject,$body);
echo "message sent! <a href="contacts.html">click here </a> to return." 
?>